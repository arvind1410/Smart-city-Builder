package com.mirror.cabbooking;

import android.app.Activity;
import android.os.Bundle;
import android.widget.EditText;
import android.widget.Spinner;
import android.widget.TextView;

/**
 * Created by arunkumar on 17/8/17.
 */

public class SCResultsActivity  extends Activity {


    public TextView mareaname;
    public TextView mflood;
    public TextView msoil;


    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.sc_results);

        mareaname = (TextView) findViewById(R.id.edit_areaname);
        mflood = (TextView) findViewById(R.id.edit_flood);
        msoil = (TextView) findViewById(R.id.edit_soil);

        String soil = getIntent().getStringExtra("soil");
        String flood = getIntent().getStringExtra("flood");
        String area = getIntent().getStringExtra("area");

        mareaname.setText(area);
        mflood.setText(flood);
        msoil.setText(soil);


    }
}
