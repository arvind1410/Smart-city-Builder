package com.mirror.cabbooking;

/**
 * Created by arunkumar on 16/8/17.
 */



        import android.app.Activity;
        import android.app.Dialog;
        import android.content.Intent;
        import android.os.Bundle;
        import android.util.Log;
        import android.view.View;
        import android.view.View.OnClickListener;
        import android.widget.AdapterView;
        import android.widget.ArrayAdapter;
        import android.widget.Button;
        import android.widget.EditText;
        import android.widget.Spinner;
        import android.widget.Toast;

        import com.google.android.gms.maps.model.LatLng;

        import java.util.ArrayList;
        import java.util.List;

public class SCConfigureActivity extends Activity implements OnClickListener, AdapterView.OnItemSelectedListener {
    /**
     * Called when the activity is first created.
     */

    private EditText mareaname;
    private Spinner flood;
    private Spinner soil_quality;

    private Button mbutton_add;

    ArrayList<LatLng> point;

    String areatext;
    String index;
    String latitude;
    String longitude;
    String soil_quality_db;
    String flood_db;


    //private Button mbutton_submit;

    String user_name;
    String password;


    Dialog dialog;
    String ip;
    DatabaseHandler db ;

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.add_location);

        point = (ArrayList<LatLng>) getIntent().getSerializableExtra("mylist");

         db = new DatabaseHandler(this);

        Log.d("Insert: ", "Inserting ..");


        mareaname = (EditText) findViewById(R.id.edit_areaname);
        flood = (Spinner) findViewById(R.id.edit_flood);
        soil_quality = (Spinner) findViewById(R.id.edit_soil);

        mbutton_add = (Button) findViewById(R.id.button_add);

        mbutton_add.setOnClickListener(this);

        // Spinner Drop down elements
        List<String> flood_area = new ArrayList<String>();
        flood_area.add("No");
        flood_area.add("Yes");

        List<String> soil = new ArrayList<String>();
        soil.add("100 - 200");
        soil.add("200 - 300");
        soil.add("300 - 400");
        soil.add("400 - 500");
        soil.add("500 - 600");

        // Creating adapter for spinner
        ArrayAdapter<String> flooddataAdapter = new ArrayAdapter<String>(this, android.R.layout.simple_spinner_item, flood_area);

        // Drop down layout style - list view with radio button
        flooddataAdapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);

        // attaching data adapter to spinner
        flood.setAdapter(flooddataAdapter);

        // Creating adapter for spinner
        ArrayAdapter<String> soildataAdapter = new ArrayAdapter<String>(this, android.R.layout.simple_spinner_item, soil);

        // Drop down layout style - list view with radio button
        soildataAdapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);

        // attaching data adapter to spinner
        soil_quality.setAdapter(soildataAdapter);
        soil_quality.setOnItemSelectedListener(this);
        flood.setOnItemSelectedListener(this);





    }


    @Override
    public void onClick(View view) {

        switch (view.getId()){

            case R.id.button_add:

                for(int i = 0 ; i < point.size() ; i++){

                    areatext = mareaname.getText().toString();
                    index = i + "" ;
                    latitude = point.get(i).latitude + "";
                    longitude = point.get(i).longitude + "";
                    //soil_quality_db = "Yes" ;
                    //flood_db = "100 - 200" ;

                    db.addLocation(areatext,index,latitude, longitude, soil_quality_db, flood_db);

                }

                db.getAllContacts();

                Toast.makeText(this,"Location added successfully", Toast.LENGTH_SHORT).show();
                break;
        }

/*
        String name = mareaname.getText().toString();
        String quantity = mquantity.getText().toString();
        String price = mprice.getText().toString();

        if(name.length() == 0 || quantity.length() == 0 || price.length() == 0){
            Toast.makeText(this, "All fields are mandatory. Please enter data for all fields", Toast.LENGTH_SHORT).show();
        }

        DatabaseHandler db = new DatabaseHandler(this);

        Log.d("Insert: ", "Inserting ..");
        db.addContact(new Item(name,price,quantity));

        Toast.makeText(this, "Item added successfully", Toast.LENGTH_SHORT).show();
//        this.finish();

        String qrData = name;

        Bundle extras = new Bundle();
        extras.putString("qrData",qrData);

        Intent i = new Intent(this,QRActivity.class);

        i.putExtras(extras);
        startActivity(i);



        //Intent l = new Intent(this,CuisineListActivity.class);
        //l.putExtras(bundle);
        //startActivity(l);


*/
    }


    @Override
    public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {

        //Toast.makeText(this, parent.getItemAtPosition(position).toString(), Toast.LENGTH_SHORT).show();

       switch(parent.getId()){

           case R.id.edit_flood:

               flood_db = parent.getItemAtPosition(position).toString();
//               Toast.makeText(this,flood_db+" " , Toast.LENGTH_SHORT).show();
               break;

           case R.id.edit_soil:
               soil_quality_db = parent.getItemAtPosition(position).toString();
  //             Toast.makeText(this,soil_quality_db+" " , Toast.LENGTH_SHORT).show();
               break;

       }
        //String item = parent.getItemAtPosition(position).toString();
    }

    @Override
    public void onNothingSelected(AdapterView<?> adapterView) {

    }
}