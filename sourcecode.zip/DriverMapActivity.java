package com.mirror.cabbooking;

/**
 * Created by arunkumar on 20/4/17.
 */

import android.content.Intent;
import android.graphics.Color;
import android.location.Geocoder;
import android.location.Location;
import android.support.annotation.NonNull;
import android.support.annotation.Nullable;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.telephony.SmsManager;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.Toast;

import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;
import com.google.android.gms.common.ConnectionResult;
import com.google.android.gms.common.api.GoogleApiClient;
import android.location.Address;

import com.google.android.gms.location.LocationRequest;
import com.google.android.gms.location.LocationServices;
import com.google.android.gms.maps.CameraUpdateFactory;
import com.google.android.gms.maps.GoogleMap;
import com.google.android.gms.maps.OnMapReadyCallback;
import com.google.android.gms.maps.SupportMapFragment;
import com.google.android.gms.maps.model.LatLng;
import com.google.android.gms.maps.model.Marker;
import com.google.android.gms.maps.model.MarkerOptions;
import com.google.android.gms.maps.model.PolylineOptions;

import java.util.ArrayList;
import java.util.List;
import java.util.Locale;

public class DriverMapActivity extends AppCompatActivity implements GoogleApiClient.ConnectionCallbacks,
        GoogleApiClient.OnConnectionFailedListener,
         View.OnClickListener {

    GoogleMap googleMap;
    String lati;
    String longi;

    Location mLastLocation;
    Marker mCurrLocationMarker;
    LocationRequest mLocationRequest;
    GoogleApiClient mGoogleApiClient;

    ArrayList<LatLng> points;

    GoogleMap map;

    //Button mride;
    Button mconfigure;
    //Button mlogoff;

    Double curr_lat ;
    Double curr_long ;

    String address1 ;

    LatLng test;

    //static final LatLng PARIS = new LatLng(48.858093, 2.294694);

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.sc_admin);
        points = new ArrayList<LatLng>();


     //   mride = (Button) findViewById(R.id.button_ride);
        mconfigure = (Button) findViewById(R.id.button_config);
      //  mlogoff = (Button) findViewById(R.id.button_logoff);

       // mride.setOnClickListener(this);
        mconfigure.setOnClickListener(this);
       // mlogoff.setOnClickListener(this);


        SupportMapFragment mapFragment = (SupportMapFragment) getSupportFragmentManager().findFragmentById(R.id.map);

        mapFragment.getMapAsync(new OnMapReadyCallback() {
            @Override
            public void onMapReady(GoogleMap googleMap) {

              //  buildGoogleApiClient();

              //  googleMap.setMapType(GoogleMap.MAP_TYPE_HYBRID);

                map =  googleMap;
                map.moveCamera( CameraUpdateFactory.newLatLngZoom(new LatLng(12.011886,79.856851) , 14.0f) );

                map.setMyLocationEnabled(true);




                map.setOnMapClickListener(new GoogleMap.OnMapClickListener() {

                    @Override
                    public void onMapClick(LatLng point) {

                        MarkerOptions markerOptions = new MarkerOptions();

                        markerOptions.position(point);

                        markerOptions.title("Position");

                        markerOptions.snippet("Latitude:"+point.latitude+","+"Longitude:"+point.longitude);

                        PolylineOptions polylineOptions = new PolylineOptions();

                        polylineOptions.color(Color.RED);

                        polylineOptions.width(3);

                        points.add(point);

                        polylineOptions.addAll(points);

                        map.addPolyline(polylineOptions);



                    //    map.addMarker(markerOptions);

                     /*   Geocoder geo;
                        List<Address> adrs = null;
                        geo = new Geocoder(MainActivity.this, Locale.getDefault());

                        try {
                            adrs = geo.getFromLocation(point.latitude, point.longitude, 1);

                        } catch (IOException e) {
                            // TODO Auto-generated catch block
                            e.printStackTrace();
                        }
                        postalCode = adrs.get(0).getPostalCode(); */

                    }

                });



                //  googleMap.setMyLocationEnabled(true);

             //   googleMap.addMarker(new MarkerOptions().position(test).icon(BitmapDescriptorFactory.fromResource(R.drawable.taxi)));

             //   googleMap.moveCamera(CameraUpdateFactory.newLatLngZoom(test, 20));
             //   googleMap.animateCamera(CameraUpdateFactory.zoomTo(15), 2000, null);

            }
        });





    }

    /*@Override
    public void onLocationChanged(Location location) {
        mLastLocation = location;
        if (mCurrLocationMarker != null) {
            mCurrLocationMarker.remove();
        }

        //Place current location marker
        LatLng latLng = new LatLng(location.getLatitude(), location.getLongitude());
        Toast.makeText(DriverMapActivity.this, "New Lat : " + location.getLatitude() + "New Long :" + location.getLongitude(), Toast.LENGTH_SHORT).show();

        curr_lat = location.getLatitude();
        curr_long = location.getLongitude() ;

        updateLocation();
        //   getLocationName();


    }*/



    @Override
    public void onConnected(@Nullable Bundle bundle) {

        mLocationRequest = new LocationRequest();
        mLocationRequest.setInterval(1000);
        mLocationRequest.setFastestInterval(1000);
        mLocationRequest.setPriority(LocationRequest.PRIORITY_BALANCED_POWER_ACCURACY);

        //LocationServices.FusedLocationApi.requestLocationUpdates(mGoogleApiClient, mLocationRequest, this);


    }

    protected synchronized void buildGoogleApiClient() {
        mGoogleApiClient = new GoogleApiClient.Builder(this)
                .addConnectionCallbacks(this)
                .addOnConnectionFailedListener(this)
                .addApi(LocationServices.API)
                .build();
        mGoogleApiClient.connect();
    }


    @Override
    public void onConnectionSuspended(int i) {

    }

    @Override
    public void onConnectionFailed(@NonNull ConnectionResult connectionResult) {

    }

    @Override
    public void onClick(View view) {

        String phone_no = "8807494202";
        switch(view.getId()){


            case R.id.button_logoff:

                this.finish();
                break;

            case R.id.button_config:

                Intent l = new Intent(this,SCConfigureActivity.class);
                l.putExtra("mylist",points);
                startActivity(l);

              /*  getLocationName();
                SmsManager smsManager1 = SmsManager.getDefault();
                String sms1= "Ride request from  " +  "Position : Latitude : " + curr_lat + "Longitude : " + curr_long + address1;
                smsManager1.sendTextMessage("7904046927", null, sms1, null, null);

                Toast.makeText(DriverMapActivity.this, "Ride Request submitted. Cab is on the way", Toast.LENGTH_SHORT).show();
*/
                break;

            case R.id.button_sos:

                getLocationName();

                Double d = distance(curr_lat,12.9229153,curr_long,80.1274558);
               // Double d = distance(curr_lat,13.052192,curr_long,80.212051);
                if(d <= 1.5){
                    phone_no = "9047693630";
                }else{
                    phone_no = "8807494202";

                }
                SmsManager smsManager2 = SmsManager.getDefault();
                String sms2 = "Emergency Request for Driver in CAB TN07 BS 8888   " +  "Position : Latitude : " + curr_lat + "Longitude : " + curr_long + address1;
                smsManager2.sendTextMessage(phone_no, null, sms2, null, null);

                Toast.makeText(DriverMapActivity.this, "Emergency Request submitted. Help is on the way", Toast.LENGTH_SHORT).show();

                break;
        }

    }


    public void getLocationName(){

        Geocoder geoCoder = new Geocoder(this, Locale.getDefault());
        StringBuilder builder = new StringBuilder();
        try {
            List<Address> address = geoCoder.getFromLocation(curr_lat , curr_long, 1);
            int maxLines = address.get(0).getMaxAddressLineIndex();
            for (int i = 0; i < maxLines; i++) {
                String addressStr = address.get(0).getAddressLine(i);
                builder.append(addressStr);
                builder.append(" ");
            }

            if(builder!=null){

                String fnialAddress = builder.toString(); //This is the complete address.
                Toast.makeText(DriverMapActivity.this, "Address : " + fnialAddress, Toast.LENGTH_SHORT).show();
                address1 = fnialAddress;

            }



        }catch(Exception e){
            e.printStackTrace();
        }



    }

    public void updateLocation(){

        // Instantiate the RequestQueue.
        RequestQueue queue = Volley.newRequestQueue(this);
       // String url ="http://mirrortech.in/soiltesting/sensors_data.php?pass=arun&a="+curr_lat+"&b="+curr_long+"&c=0&d=0";
        String url ="http://mirrortech.in/soiltesting/sensors_data.php?pass=arun&c="+curr_lat+"&d="+curr_long+"&a=0&b=0";

// Request a string response from the provided URL.
        StringRequest stringRequest = new StringRequest(Request.Method.GET, url,
                new Response.Listener<String>() {
                    @Override
                    public void onResponse(String response) {
                        // Display the first 500 characters of the response string.
                        //mTextView.setText("Response is: "+ response.substring(0,500));

                        Log.d("response", response);




                    }
                }, new Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError error) {
                Log.d("Error","Error");
                //   mTextView.setText("That didn't work!");
            }
        });
// Add the request to the RequestQueue.
        queue.add(stringRequest);



    }

    public static double distance(double lat1, double lat2, double lon1,
                                  double lon2) {

        final int R = 6371; // Radius of the earth

        Double latDistance = Math.toRadians(lat2 - lat1);
        Double lonDistance = Math.toRadians(lon2 - lon1);
        Double a = Math.sin(latDistance / 2) * Math.sin(latDistance / 2)
                + Math.cos(Math.toRadians(lat1)) * Math.cos(Math.toRadians(lat2))
                * Math.sin(lonDistance / 2) * Math.sin(lonDistance / 2);
        Double c = 2 * Math.atan2(Math.sqrt(a), Math.sqrt(1 - a));
        double distance = R * c ; // convert to kilometers



        distance = Math.pow(distance, 2); // + Math.pow(height, 2);

        return Math.sqrt(distance);
    }
}